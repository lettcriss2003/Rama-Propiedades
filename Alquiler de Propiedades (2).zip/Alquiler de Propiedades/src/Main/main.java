/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import controlador.PropiedadDao;
import java.util.HashSet;
import java.util.Set;
import vista.FrmDescripcionPropiedad;

/**
 *
 * @author lettc
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        FrmDescripcionPropiedad frm = new FrmDescripcionPropiedad();
//        frm.setVisible(true);
        PropiedadDao propiedad1 = new PropiedadDao();
        propiedad1.getPropiedad().setCalleP("Zamora");
        propiedad1.getPropiedad().setAguaCaliente(Boolean.FALSE);
        //System.out.println(propiedad1.getPropiedad().toString());
        try {
            propiedad1.guardar();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
